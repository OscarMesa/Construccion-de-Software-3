drop table if exists tbl_permisos ;
drop table if exists tbl_paginas ;
drop table if exists tbl_usuarios ;


create table tbl_usuarios (
    id integer,
    id_usuario varchar (30), --Equivalente al login del usuario
    nombre varchar (255) not null,
    apellido varchar (255) not null,
    password varchar (40),
    constraint pk_usuarios primary key (id_usuario,id)
);
--Password 1234, el hash SHA1 es 7110eda4d09e062aa5e4a390b0a572ac0d2c0220
INSERT INTO tbl_usuarios (id,id_usuario, nombre, apellido, password) VALUES (1,'dthomas', 'Diego', 'Thomas', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220');
INSERT INTO tbl_usuarios (id,id_usuario, nombre, apellido, password) VALUES (1,'oskar', 'Oscar', 'Oskar.Mexa', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220');
create table tbl_paginas (
    id_pagina serial, 
    nombre varchar (255) not null,
    url varchar (255) not null,
    constraint pk_paginas primary key (id_pagina)
);
INSERT INTO tbl_paginas(nombre,url) VALUES('prueba','gogopoint.com');
INSERT INTO tbl_paginas(nombre,url) VALUES('prueba1','youtube.com');
INSERT INTO tbl_paginas(nombre,url) VALUES('prueba2','google.com');

create table tbl_permisos (
    id integer,
    id_usuario  varchar (30), 
    id_pagina integer,
    constraint pk_permisos primary key (id_usuario, id_pagina),
    constraint fk_permisos_usuarios foreign key (id_usuario,id) references tbl_usuarios on delete cascade on update cascade,
    constraint fk_permisos_paginas foreign key (id_pagina) references tbl_paginas on delete restrict on update cascade
);
INSERT INTO tbl_permisos VALUES(1,'dthomas',1);
INSERT INTO tbl_permisos VALUES(1,'dthomas',2);
INSERT INTO tbl_permisos VALUES(1,'dthomas',3);
INSERT INTO tbl_permisos VALUES(1,'oskar',1);
INSERT INTO tbl_permisos VALUES(1,'oskar',2);
INSERT INTO tbl_permisos VALUES(1,'oskar',3);