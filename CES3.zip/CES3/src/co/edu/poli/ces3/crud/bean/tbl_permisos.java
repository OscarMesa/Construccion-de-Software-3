package co.edu.poli.ces3.crud.bean;

import co.edu.poli.ces3.crud.Columna;
import co.edu.poli.ces3.crud.Crud;
import java.net.URL;
 import java.util.Collections;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public final class tbl_permisos extends Crud {

    @Columna(ClavePrimaria=false,AutoNumerico=false, Requered = false,NameForeingKey = "tbl_usuarios.id")
    private java.lang.Integer Id;

    @Columna(ClavePrimaria=true,AutoNumerico=false, Requered = true,NameForeingKey = "tbl_usuarios.id_usuario")
    private java.lang.String Id_usuario;

    @Columna(ClavePrimaria=true,AutoNumerico=false, Requered = true,NameForeingKey = "tbl_paginas.id_pagina")
    private java.lang.Integer Id_pagina;



     public java.lang.Integer Id(){
           return this.Id;
     }

     public java.lang.String Id_usuario(){
           return this.Id_usuario;
     }

     public java.lang.Integer Id_pagina(){
           return this.Id_pagina;
     }



     public void setId(java.lang.Integer Id){
       this.Id = Id;
     }

     public void setId_usuario(java.lang.String Id_usuario){
       this.Id_usuario = Id_usuario;
     }

     public void setId_pagina(java.lang.Integer Id_pagina){
       this.Id_pagina = Id_pagina;
     }

    public Integer getId() {
        return Id;
    }

    public String getId_usuario() {
        return Id_usuario;
    }

    public Integer getId_pagina() {
        return Id_pagina;
    }

     public tbl_permisos(){
     }
     
     public ArrayList<tbl_permisos> select()
     {
         return (ArrayList<tbl_permisos>)(super.select());
     }

     public static void main(String... args){
         
         tbl_permisos x = new tbl_permisos();
         x.setId_pagina(1);
         x.setId_usuario("dthomas");
         StringBuilder d = new StringBuilder("oscar.mesa");
         //System.out.println(d.startsWith("Oscar."));
         //System.out.println();
         for(tbl_permisos per: x.select())
         {
             System.out.println(per.getId());
         }
         
         
//         Package[] pa = Package.getPackages();
//        for (int i = 0; i < pa.length; i++) {
//            Package p = pa[i];
//            System.out.println("\"" + p.getName() + "\", ");
//
//         
//     }
//        
//      \
         
}
     }