package co.edu.poli.ces3.crud.bean;

import co.edu.poli.ces3.crud.Columna;
import co.edu.poli.ces3.crud.Crud;

public final class tbl_paginas extends Crud {

     @Columna(ClavePrimaria=true,AutoNumerico=true, Requered = true,NameForeingKey = "")
    private java.lang.Integer Id_pagina;

     @Columna(ClavePrimaria=false,AutoNumerico=false, Requered = true,NameForeingKey = "")
    private java.lang.String Nombre;

     @Columna(ClavePrimaria=false,AutoNumerico=false, Requered = true,NameForeingKey = "")
    private java.lang.String Url;



     public java.lang.Integer Id_pagina(){
           return this.Id_pagina;
     }

     public java.lang.String Nombre(){
           return this.Nombre;
     }

     public java.lang.String Url(){
           return this.Url;
     }



     public void setId_pagina(java.lang.Integer Id_pagina){
       this.Id_pagina = Id_pagina;
     }

     public void setNombre(java.lang.String Nombre){
       this.Nombre = Nombre;
     }

     public void setUrl(java.lang.String Url){
       this.Url = Url;
     }

     public tbl_paginas(){
     }

     public static void main(String... args){
     }
}