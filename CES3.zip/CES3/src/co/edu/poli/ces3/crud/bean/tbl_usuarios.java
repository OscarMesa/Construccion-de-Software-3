package co.edu.poli.ces3.crud.bean;

import co.edu.poli.ces3.crud.Columna;
import co.edu.poli.ces3.crud.Crud;
import java.util.ArrayList;

public final class tbl_usuarios extends Crud {

     @Columna(ClavePrimaria=true,AutoNumerico=false, Requered = true,NameForeingKey = "")
    private java.lang.Integer Id;

     @Columna(ClavePrimaria=true,AutoNumerico=false, Requered = true,NameForeingKey = "")
    private java.lang.String Id_usuario;

     @Columna(ClavePrimaria=false,AutoNumerico=false, Requered = true,NameForeingKey = "")
    private java.lang.String Nombre;

     @Columna(ClavePrimaria=false,AutoNumerico=false, Requered = true,NameForeingKey = "")
    private java.lang.String Apellido;

     @Columna(ClavePrimaria=false,AutoNumerico=false, Requered = false,NameForeingKey = "")
    private java.lang.String Password;



     public java.lang.Integer Id(){
           return this.Id;
     }

     public java.lang.String Id_usuario(){
           return this.Id_usuario;
     }

     public java.lang.String Nombre(){
           return this.Nombre;
     }

     public java.lang.String Apellido(){
           return this.Apellido;
     }

     public java.lang.String Password(){
           return this.Password;
     }



     public void setId(java.lang.Integer Id){
       this.Id = Id;
     }

     public void setId_usuario(java.lang.String Id_usuario){
       this.Id_usuario = Id_usuario;
     }

     public void setNombre(java.lang.String Nombre){
       this.Nombre = Nombre;
     }

     public void setApellido(java.lang.String Apellido){
       this.Apellido = Apellido;
     }

     public void setPassword(java.lang.String Password){
       this.Password = Password;
     }

    public Integer getId() {
        return Id;
    }

    public String getId_usuario() {
        return Id_usuario;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public String getPassword() {
        return Password;
    }

     public tbl_usuarios(){
     }
     
     public ArrayList<tbl_usuarios> select()
     {
         return (ArrayList<tbl_usuarios>)(super.select());
     }
     public static void main(String... args){
         tbl_usuarios x = new tbl_usuarios();
         x.setId(1);
         for (tbl_usuarios y : x.select()) {
             System.out.println(y.getApellido());
         }
     }
}